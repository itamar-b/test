<?php

class csv{

	public static $output = array();

	public static function read_csv($file = null){
		
		if ($file == null){
			csv::$output = array();
			$file = fopen("array.csv","r");
		}
		
		while(!feof($file)){
			$current_record = fgetcsv($file);	
		    // RECURSIVE CALLING TO READING FUNCTION
			csv::read_csv($file);
		}
		
		if (isset($current_record)){
			// FILL OUTPUT IN THE END OF RECRUSIVE
			array_push(self::$output,$current_record);
		}
				
	}
	
}

// CALCULATE THE 3D ARRAY
csv::read_csv();

// PRINT THER 3D ARRAY
print_r(csv::$output);


