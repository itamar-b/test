$(document).ready(function(){
	

		var translator = {"א":1, "ב":2, "ג":3,"ד":4,"ה":5,"ו":6,"ז":7,"ח":8,"ט":9,"י":10,"כ":20,"ל":"30","מ":40,"נ":"50","ס":60,"ע":70,"פ":"80","צ":90,"ק":100,"ר":200,"ש":300,"ת":400,"ך":"20","ם":40,"ן":50,"ף":80,"ץ":80};
	
		$( "form[name='genatria_frm'] #calc" ).click(function() {
			var input_val = $(this).prev("input").val().trim();
			if (input_val == "" || input_val.match(/\d+/g) != null){
				$("#resault").html("נא לרשום טקסט בלבד בתיבת הטקסט");
				return;
			}
			
			
			var sum = 0;
			
			for (i=0;i<input_val.length;i++){
				var current_char = input_val[i];
				Object.keys(translator).forEach(function(k){
					if (k == current_char){
						sum = sum + (translator[k] * 1);
					}					
				});
			}
			
			$("#resault").html("ערך גימטרי " + sum);
			
			
		});
			
		
});

